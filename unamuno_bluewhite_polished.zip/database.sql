create extension if not exists "pgcrypto";

-- Site settings
create table if not exists site_settings (
  id uuid primary key,
  title text,
  description text,
  accent text,
  created_at timestamptz default now()
);

-- Items (posts)
create table if not exists items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  created_at timestamptz default now()
);

-- Calendar events
create table if not exists calendar_events (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  note text,
  created_at timestamptz default now()
);

alter table items enable row level security;
alter table calendar_events enable row level security;
alter table site_settings enable row level security;

-- Policies
create policy if not exists "Public read items" on items for select using (true);
create policy if not exists "Public insert items" on items for insert with check (true);
create policy if not exists "Admin delete items" on items for delete using (auth.role()='authenticated');

create policy if not exists "Public read calendar" on calendar_events for select using (true);
create policy if not exists "Admin insert calendar" on calendar_events for insert with check (auth.role()='authenticated');
create policy if not exists "Admin delete calendar" on calendar_events for delete using (auth.role()='authenticated');

create policy if not exists "Public read settings" on site_settings for select using (true);
create policy if not exists "Admin upsert settings" on site_settings for all using (auth.role()='authenticated');